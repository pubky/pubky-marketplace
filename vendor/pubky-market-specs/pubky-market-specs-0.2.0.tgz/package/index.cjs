/* @ts-self-types="./pubky_market_specs.d.ts" */

class DropResult {
    static __wrap(ptr) {
        const obj = Object.create(DropResult.prototype);
        obj.__wbg_ptr = ptr;
        DropResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        DropResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_dropresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyMarketDrop}
     */
    get drop() {
        const ret = wasm.dropresult_drop(this.__wbg_ptr);
        return PubkyMarketDrop.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.dropresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) DropResult.prototype[Symbol.dispose] = DropResult.prototype.free;
exports.DropResult = DropResult;

class ListingResult {
    static __wrap(ptr) {
        const obj = Object.create(ListingResult.prototype);
        obj.__wbg_ptr = ptr;
        ListingResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ListingResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_listingresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyMarketListing}
     */
    get listing() {
        const ret = wasm.listingresult_listing(this.__wbg_ptr);
        return PubkyMarketListing.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.listingresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) ListingResult.prototype[Symbol.dispose] = ListingResult.prototype.free;
exports.ListingResult = ListingResult;

/**
 * Each `build*` function:
 * - Accepts the record as a plain camelCase JSON object and the owner's pubky.
 * - Sanitizes and validates the record.
 * - Derives the ID where the record has one.
 * - Returns the record with its `meta` (`id`, `path`, `url`), or a descriptive error.
 */
class Meta {
    static __wrap(ptr) {
        const obj = Object.create(Meta.prototype);
        obj.__wbg_ptr = ptr;
        MetaFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MetaFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_meta_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    get id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.meta_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get path() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.meta_path(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get url() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.meta_url(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) Meta.prototype[Symbol.dispose] = Meta.prototype.free;
exports.Meta = Meta;

class OrderReceiptResult {
    static __wrap(ptr) {
        const obj = Object.create(OrderReceiptResult.prototype);
        obj.__wbg_ptr = ptr;
        OrderReceiptResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        OrderReceiptResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_orderreceiptresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.orderreceiptresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyMarketOrderReceipt}
     */
    get order_receipt() {
        const ret = wasm.orderreceiptresult_order_receipt(this.__wbg_ptr);
        return PubkyMarketOrderReceipt.__wrap(ret);
    }
}
if (Symbol.dispose) OrderReceiptResult.prototype[Symbol.dispose] = OrderReceiptResult.prototype.free;
exports.OrderReceiptResult = OrderReceiptResult;

/**
 * The result of parsing a Market URI: the owner, the resource name (the
 * `Display` form of [`Resource`], e.g. `marketplace/v1/listings`) and the
 * resource id when it has one.
 */
class ParsedUriResult {
    static __wrap(ptr) {
        const obj = Object.create(ParsedUriResult.prototype);
        obj.__wbg_ptr = ptr;
        ParsedUriResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ParsedUriResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_parseduriresult_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    get resource() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.parseduriresult_resource(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string | undefined}
     */
    get resource_id() {
        const ret = wasm.parseduriresult_resource_id(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @returns {string}
     */
    get user_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.parseduriresult_user_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) ParsedUriResult.prototype[Symbol.dispose] = ParsedUriResult.prototype.free;
exports.ParsedUriResult = ParsedUriResult;

/**
 * A validated Pubky public key in its 52-character z-base-32 form.
 *
 * Native targets accept exactly the keys `pubky::PublicKey` accepts for a
 * 52-character input (the decoded 32 bytes must be a valid Ed25519 point)
 * and store the canonical re-encoding, as `pubky-app-specs` does. The wasm
 * target checks length and encoding only, also as `pubky-app-specs` does.
 */
class PubkyId {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyIdFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyid_free(ptr, 0);
    }
}
if (Symbol.dispose) PubkyId.prototype[Symbol.dispose] = PubkyId.prototype.free;
exports.PubkyId = PubkyId;

/**
 * Represents a marketplace drop: a seller's scheduled, limited-quantity
 * release bundling one or more of their listings.
 *
 * URI: /pub/pubky.app/marketplace/v1/drops/:drop_id
 *
 * Where drop_id follows the marketplace entity-id convention and must match
 * the record's `dropId` field. Unlike the private order receipt, this is a
 * PUBLIC record wired into `PubkyMarketObject` and the URI parser so Nexus can
 * index it.
 *
 * `startsAt`/`endsAt` are the seller's declared schedule intent; the
 * marketplace transaction service enforces the real sale window and the
 * real stock counters. `listingIds` are the seller's OWN listings: the drop
 * record owner is the listing owner by definition (both live under the same
 * pubky's `/pub/pubky.app/marketplace/v1/` tree), so no cross-owner
 * reference form exists here.
 */
class PubkyMarketDrop {
    static __wrap(ptr) {
        const obj = Object.create(PubkyMarketDrop.prototype);
        obj.__wbg_ptr = ptr;
        PubkyMarketDropFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketDropFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketdrop_free(ptr, 0);
    }
    /**
     * Per-buyer purchase cap, 1-100; never above `total_quantity`.
     * @returns {bigint}
     */
    get per_buyer_limit() {
        const ret = wasm.__wbg_get_pubkymarketdrop_per_buyer_limit(this.__wbg_ptr);
        return ret;
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkymarketdrop_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkymarketdrop_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * Total units across the drop, 1-1000000.
     * @returns {bigint}
     */
    get total_quantity() {
        const ret = wasm.__wbg_get_pubkymarketdrop_total_quantity(this.__wbg_ptr);
        return ret;
    }
    /**
     * Getter for `drop_id`.
     * @returns {string}
     */
    get drop_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketdrop_drop_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {any} js_value
     * @returns {PubkyMarketDrop}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkymarketdrop_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyMarketDrop.__wrap(ret[0]);
    }
    /**
     * Getter for `owner_pubky`.
     * @returns {string}
     */
    get owner_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketdrop_owner_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `title`.
     * @returns {string}
     */
    get title() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketdrop_title(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkymarketdrop_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Per-buyer purchase cap, 1-100; never above `total_quantity`.
     * @param {bigint} arg0
     */
    set per_buyer_limit(arg0) {
        wasm.__wbg_set_pubkymarketdrop_per_buyer_limit(this.__wbg_ptr, arg0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkymarketdrop_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkymarketdrop_schema_version(this.__wbg_ptr, arg0);
    }
    /**
     * Total units across the drop, 1-1000000.
     * @param {bigint} arg0
     */
    set total_quantity(arg0) {
        wasm.__wbg_set_pubkymarketdrop_total_quantity(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketDrop.prototype[Symbol.dispose] = PubkyMarketDrop.prototype.free;
exports.PubkyMarketDrop = PubkyMarketDrop;

/**
 * How a drop sells. Closed-world: this version defines only `fcfs`
 * (first-come, first-served); any future format is a schema version bump,
 * so records carrying an unknown format are rejected rather than
 * misinterpreted.
 * @enum {0}
 */
const PubkyMarketDropFormat = Object.freeze({
    Fcfs: 0, "0": "Fcfs",
});
exports.PubkyMarketDropFormat = PubkyMarketDropFormat;

/**
 * How much remaining-stock detail the seller wants the public projection to
 * reveal while the drop runs. This is the seller's DECLARED policy —
 * ENFORCEMENT is server-side: the transaction service (which holds the real
 * counters) decides what each stock query answers, and the public record
 * merely tells clients which presentation the seller chose.
 * @enum {0 | 1 | 2}
 */
const PubkyMarketDropStockDisplay = Object.freeze({
    Exact: 0, "0": "Exact",
    Bands: 1, "1": "Bands",
    Hidden: 2, "2": "Hidden",
});
exports.PubkyMarketDropStockDisplay = PubkyMarketDropStockDisplay;

/**
 * How the item can be delivered to the buyer.
 * @enum {0 | 1 | 2 | 3}
 */
const PubkyMarketFulfillmentMethod = Object.freeze({
    Physical: 0, "0": "Physical",
    Digital: 1, "1": "Digital",
    Pickup: 2, "2": "Pickup",
    /**
     * Carrier delivery. Distinct from `physical`, which still requires package
     * facts and a shipping option. A listing may offer `shipping` alone.
     */
    Shipping: 3, "3": "Shipping",
});
exports.PubkyMarketFulfillmentMethod = PubkyMarketFulfillmentMethod;

/**
 * Represents a marketplace listing published by a seller.
 *
 * URI: /pub/pubky.app/marketplace/v1/listings/:listing_id
 *
 * Where listing_id is Crockford-base32 encoding of a timestamp and must
 * match the record's `listingId` field.
 */
class PubkyMarketListing {
    static __wrap(ptr) {
        const obj = Object.create(PubkyMarketListing.prototype);
        obj.__wbg_ptr = ptr;
        PubkyMarketListingFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketListingFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketlisting_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    get adult_only() {
        const ret = wasm.__wbg_get_pubkymarketlisting_adult_only(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkymarketlisting_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkymarketlisting_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace category taxonomy version, `1` or greater. The category
     * tree and the attribute expectations per category are versioned CLIENT
     * configuration keyed by this number — the record stays self-describing
     * without the spec churning per category.
     * @returns {bigint}
     */
    get taxonomy_version() {
        const ret = wasm.__wbg_get_pubkymarketlisting_taxonomy_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * Getter for `description`.
     * @returns {string}
     */
    get description() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketlisting_description(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {any} js_value
     * @returns {PubkyMarketListing}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkymarketlisting_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyMarketListing.__wrap(ret[0]);
    }
    /**
     * Getter for `listing_id`.
     * @returns {string}
     */
    get listing_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketlisting_listing_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `owner_pubky`.
     * @returns {string}
     */
    get owner_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketlisting_owner_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `title`.
     * @returns {string}
     */
    get title() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketlisting_title(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkymarketlisting_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {boolean} arg0
     */
    set adult_only(arg0) {
        wasm.__wbg_set_pubkymarketlisting_adult_only(this.__wbg_ptr, arg0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkymarketlisting_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkymarketlisting_schema_version(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace category taxonomy version, `1` or greater. The category
     * tree and the attribute expectations per category are versioned CLIENT
     * configuration keyed by this number — the record stays self-describing
     * without the spec churning per category.
     * @param {bigint} arg0
     */
    set taxonomy_version(arg0) {
        wasm.__wbg_set_pubkymarketlisting_taxonomy_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketListing.prototype[Symbol.dispose] = PubkyMarketListing.prototype.free;
exports.PubkyMarketListing = PubkyMarketListing;

/**
 * Physical condition of the listed item.
 * @enum {0 | 1 | 2 | 3 | 4 | 5}
 */
const PubkyMarketListingCondition = Object.freeze({
    New: 0, "0": "New",
    LikeNew: 1, "1": "LikeNew",
    Excellent: 2, "2": "Excellent",
    Good: 3, "3": "Good",
    Fair: 4, "4": "Fair",
    ForParts: 5, "5": "ForParts",
});
exports.PubkyMarketListingCondition = PubkyMarketListingCondition;

/**
 * Media attachment type.
 * @enum {0 | 1}
 */
const PubkyMarketListingMediaKind = Object.freeze({
    Image: 0, "0": "Image",
    Video: 1, "1": "Video",
});
exports.PubkyMarketListingMediaKind = PubkyMarketListingMediaKind;

/**
 * Lifecycle state of a marketplace listing.
 * @enum {0 | 1 | 2 | 3}
 */
const PubkyMarketListingState = Object.freeze({
    Active: 0, "0": "Active",
    Paused: 1, "1": "Paused",
    Ended: 2, "2": "Ended",
    Removed: 3, "3": "Removed",
});
exports.PubkyMarketListingState = PubkyMarketListingState;

/**
 * Coarse public location attached to shops and listings.
 */
class PubkyMarketLocation {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketLocationFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketlocation_free(ptr, 0);
    }
}
if (Symbol.dispose) PubkyMarketLocation.prototype[Symbol.dispose] = PubkyMarketLocation.prototype.free;
exports.PubkyMarketLocation = PubkyMarketLocation;

/**
 * Integer money in minor units, e.g. cents or satoshis.
 *
 * `amount_minor` is always an integer amount of the smallest unit,
 * `currency` is an uppercase asset code and `exponent` the number of
 * decimal places between minor and major units.
 */
class PubkyMarketMoney {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketMoneyFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketmoney_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get amount_minor() {
        const ret = wasm.__wbg_get_pubkymarketmoney_amount_minor(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get exponent() {
        const ret = wasm.__wbg_get_pubkymarketmoney_exponent(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {bigint} arg0
     */
    set amount_minor(arg0) {
        wasm.__wbg_set_pubkymarketmoney_amount_minor(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set exponent(arg0) {
        wasm.__wbg_set_pubkymarketmoney_exponent(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketMoney.prototype[Symbol.dispose] = PubkyMarketMoney.prototype.free;
exports.PubkyMarketMoney = PubkyMarketMoney;

/**
 * A PRIVATE portable order receipt — the buyer's or seller's own durable
 * copy of a completed order, written to their OWN homeserver.
 *
 * URI: /priv/pubky.app/marketplace/v1/receipts/:receipt_id
 *
 * The marketplace transaction service holds the canonical order state, but
 * a service is an operator that can disappear. This record is the credible
 * exit for orders: each party keeps a signed, self-contained receipt (the
 * embedded `receiptAttestation` JWS is offline-verifiable — see
 * `order_receipt_attestation.rs`) on storage they control, so a purchase
 * history survives the operator.
 *
 * Like the watchlist, this is a `/priv/` record: an order history reveals
 * counterparties, amounts, and purchase timing, so it must never be
 * world-readable, directory-listable, or Nexus-indexable. It is therefore
 * deliberately NOT wired into `PubkyMarketObject` / the URI parser used by
 * watchers and indexers: nothing under `/priv/` is index-visible, and this
 * record only ever travels between the owner's own sessions.
 *
 * Unlike the watchlist singleton, receipts are one record per order under
 * `receipts/:receipt_id` (the service's receipt UUID): receipts are
 * immutable facts, not merge targets, and per-id paths let a client sync
 * incrementally instead of rewriting one growing document.
 */
class PubkyMarketOrderReceipt {
    static __wrap(ptr) {
        const obj = Object.create(PubkyMarketOrderReceipt.prototype);
        obj.__wbg_ptr = ptr;
        PubkyMarketOrderReceiptFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketOrderReceiptFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketorderreceipt_free(ptr, 0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkymarketorderreceipt_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkymarketorderreceipt_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyMarketOrderReceipt}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkymarketorderreceipt_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyMarketOrderReceipt.__wrap(ret[0]);
    }
    /**
     * Getter for `order_id`.
     * @returns {string}
     */
    get order_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketorderreceipt_order_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `owner_pubky`.
     * @returns {string}
     */
    get owner_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketorderreceipt_owner_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `receipt_id`.
     * @returns {string}
     */
    get receipt_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketorderreceipt_receipt_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkymarketorderreceipt_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkymarketorderreceipt_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkymarketorderreceipt_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketOrderReceipt.prototype[Symbol.dispose] = PubkyMarketOrderReceipt.prototype.free;
exports.PubkyMarketOrderReceipt = PubkyMarketOrderReceipt;

/**
 * The record owner's side of the order.
 * @enum {0 | 1}
 */
const PubkyMarketOrderReceiptRole = Object.freeze({
    Buyer: 0, "0": "Buyer",
    Seller: 1, "1": "Seller",
});
exports.PubkyMarketOrderReceiptRole = PubkyMarketOrderReceiptRole;

/**
 * Represents a marketplace review of a trade counterparty.
 *
 * URI: /pub/pubky.app/marketplace/v1/reviews/:review_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/marketplace/v1/reviews/FPB0AM9S93Q3M1GFY1KV09GMQM`
 *
 * Where review_id is
 * Crockford-base32(Blake3("{reviewed_listing_uri}:{subject_pubky}:{role}:{order_ref}")[:half])
 * and must match the record's `reviewId` field. A record without `orderRef`
 * (written before per-order reviews) keeps the three-part
 * `"{reviewed_listing_uri}:{subject_pubky}:{role}"` input.
 */
class PubkyMarketReview {
    static __wrap(ptr) {
        const obj = Object.create(PubkyMarketReview.prototype);
        obj.__wbg_ptr = ptr;
        PubkyMarketReviewFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketReviewFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketreview_free(ptr, 0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkymarketreview_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkymarketreview_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyMarketReview}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkymarketreview_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyMarketReview.__wrap(ret[0]);
    }
    /**
     * Getter for `listing_id`.
     * @returns {string}
     */
    get listing_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketreview_listing_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `subject_pubky`.
     * @returns {string}
     */
    get subject_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketreview_subject_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `text`.
     * @returns {string}
     */
    get text() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketreview_text(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkymarketreview_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkymarketreview_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkymarketreview_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketReview.prototype[Symbol.dispose] = PubkyMarketReview.prototype.free;
exports.PubkyMarketReview = PubkyMarketReview;

/**
 * Star ratings on a 1-5 integer scale. Only `overall` is required.
 */
class PubkyMarketReviewRatings {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketReviewRatingsFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketreviewratings_free(ptr, 0);
    }
    /**
     * @returns {bigint | undefined}
     */
    get communication() {
        const ret = wasm.__wbg_get_pubkymarketreviewratings_communication(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @returns {bigint | undefined}
     */
    get item_accuracy() {
        const ret = wasm.__wbg_get_pubkymarketreviewratings_item_accuracy(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @returns {bigint}
     */
    get overall() {
        const ret = wasm.__wbg_get_pubkymarketreviewratings_overall(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint | undefined}
     */
    get shipping() {
        const ret = wasm.__wbg_get_pubkymarketreviewratings_shipping(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @param {bigint | null} [arg0]
     */
    set communication(arg0) {
        wasm.__wbg_set_pubkymarketreviewratings_communication(this.__wbg_ptr, !isLikeNone(arg0), isLikeNone(arg0) ? BigInt(0) : arg0);
    }
    /**
     * @param {bigint | null} [arg0]
     */
    set item_accuracy(arg0) {
        wasm.__wbg_set_pubkymarketreviewratings_item_accuracy(this.__wbg_ptr, !isLikeNone(arg0), isLikeNone(arg0) ? BigInt(0) : arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set overall(arg0) {
        wasm.__wbg_set_pubkymarketreviewratings_overall(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint | null} [arg0]
     */
    set shipping(arg0) {
        wasm.__wbg_set_pubkymarketreviewratings_shipping(this.__wbg_ptr, !isLikeNone(arg0), isLikeNone(arg0) ? BigInt(0) : arg0);
    }
}
if (Symbol.dispose) PubkyMarketReviewRatings.prototype[Symbol.dispose] = PubkyMarketReviewRatings.prototype.free;
exports.PubkyMarketReviewRatings = PubkyMarketReviewRatings;

/**
 * Represents a response to a marketplace review, published by the review's
 * subject on their own homeserver.
 *
 * URI: /pub/pubky.app/marketplace/v1/review_responses/:review_id
 *
 * The path ID **equals the subject review's ID**, which gives O(1) lookup
 * in both directions and structurally caps responses at one per review
 * (revisable via `revision`).
 *
 * Authorization is structural, not cryptographic: an indexer accepts a
 * response only when the response record's `owner_pubky` equals the
 * subject review's `subjectPubky` (see [`Self::is_authorized_response_to`]).
 * An impostor's response fails that check without any signature machinery.
 */
class PubkyMarketReviewResponse {
    static __wrap(ptr) {
        const obj = Object.create(PubkyMarketReviewResponse.prototype);
        obj.__wbg_ptr = ptr;
        PubkyMarketReviewResponseFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketReviewResponseFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketreviewresponse_free(ptr, 0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkymarketreviewresponse_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkymarketreviewresponse_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyMarketReviewResponse}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkymarketreviewresponse_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyMarketReviewResponse.__wrap(ret[0]);
    }
    /**
     * Getter for `review_id`.
     * @returns {string}
     */
    get review_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketreviewresponse_review_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `review_uri`.
     * @returns {string}
     */
    get review_uri() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketreviewresponse_review_uri(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `text`.
     * @returns {string}
     */
    get text() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketreviewresponse_text(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkymarketreviewresponse_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkymarketreviewresponse_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkymarketreviewresponse_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketReviewResponse.prototype[Symbol.dispose] = PubkyMarketReviewResponse.prototype.free;
exports.PubkyMarketReviewResponse = PubkyMarketReviewResponse;

/**
 * Which side of the trade the review covers.
 * @enum {0 | 1}
 */
const PubkyMarketReviewRole = Object.freeze({
    BuyerReviewingSeller: 0, "0": "BuyerReviewingSeller",
    SellerReviewingBuyer: 1, "1": "SellerReviewingBuyer",
});
exports.PubkyMarketReviewRole = PubkyMarketReviewRole;

/**
 * A seller's reusable shipping rules: where they ship from, which countries
 * they ship to and what each zone charges. Listings reference a profile by
 * its id, or carry their own zones.
 *
 * URI: /pub/pubky.app/marketplace/v1/shipping_profiles/:profile_id
 *
 * Amounts are integer minor units of the profile's `currency` and
 * `exponent`; a listing can use the profile only in the same asset.
 */
class PubkyMarketShippingProfile {
    static __wrap(ptr) {
        const obj = Object.create(PubkyMarketShippingProfile.prototype);
        obj.__wbg_ptr = ptr;
        PubkyMarketShippingProfileFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketShippingProfileFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketshippingprofile_free(ptr, 0);
    }
    /**
     * Decimal places between the minor and major unit of `currency`.
     * @returns {bigint}
     */
    get exponent() {
        const ret = wasm.__wbg_get_pubkymarketshippingprofile_exponent(this.__wbg_ptr);
        return ret;
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkymarketshippingprofile_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkymarketshippingprofile_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyMarketShippingProfile}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkymarketshippingprofile_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyMarketShippingProfile.__wrap(ret[0]);
    }
    /**
     * Getter for `owner_pubky`.
     * @returns {string}
     */
    get owner_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketshippingprofile_owner_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `profile_id`.
     * @returns {string}
     */
    get profile_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketshippingprofile_profile_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkymarketshippingprofile_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Decimal places between the minor and major unit of `currency`.
     * @param {bigint} arg0
     */
    set exponent(arg0) {
        wasm.__wbg_set_pubkymarketshippingprofile_exponent(this.__wbg_ptr, arg0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkymarketshippingprofile_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkymarketshippingprofile_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketShippingProfile.prototype[Symbol.dispose] = PubkyMarketShippingProfile.prototype.free;
exports.PubkyMarketShippingProfile = PubkyMarketShippingProfile;

/**
 * Represents a seller's marketplace shop profile (singleton per user).
 *
 * URI: /pub/pubky.app/marketplace/v1/shop.json
 */
class PubkyMarketShop {
    static __wrap(ptr) {
        const obj = Object.create(PubkyMarketShop.prototype);
        obj.__wbg_ptr = ptr;
        PubkyMarketShopFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketShopFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketshop_free(ptr, 0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkymarketshop_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkymarketshop_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {boolean}
     */
    get vacation_mode() {
        const ret = wasm.__wbg_get_pubkymarketshop_vacation_mode(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Getter for `bio`.
     * @returns {string}
     */
    get bio() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketshop_bio(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {any} js_value
     * @returns {PubkyMarketShop}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkymarketshop_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyMarketShop.__wrap(ret[0]);
    }
    /**
     * Getter for `name`.
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketshop_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `owner_pubky`.
     * @returns {string}
     */
    get owner_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkymarketshop_owner_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkymarketshop_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkymarketshop_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkymarketshop_schema_version(this.__wbg_ptr, arg0);
    }
    /**
     * @param {boolean} arg0
     */
    set vacation_mode(arg0) {
        wasm.__wbg_set_pubkymarketshop_vacation_mode(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketShop.prototype[Symbol.dispose] = PubkyMarketShop.prototype.free;
exports.PubkyMarketShop = PubkyMarketShop;

/**
 * Represents a user's PRIVATE marketplace watchlist.
 *
 * URI: /priv/pubky.app/marketplace/v1/watchlist.json
 *
 * This is the first record under `/priv/` — the homeserver's authenticated
 * private storage (reads, listings, and writes by anyone but the owner's
 * session are refused). A watchlist reveals purchase intent, so unlike every
 * `/pub/pubky.app/` record it must not be world-readable, directory-listable,
 * or Nexus-indexable. It is therefore deliberately NOT wired into
 * `PubkyMarketObject` / the URI parser used by watchers and indexers: nothing
 * under `/priv/` is index-visible, and this record only ever travels between
 * the owner's own sessions.
 *
 * It is a SINGLE revisioned document rather than one record per watched
 * listing because: (a) watch/unwatch toggles are high-churn and a single
 * document makes each sync one `PUT` instead of a create/delete stream;
 * (b) merge needs items and tombstones resolved together atomically — two
 * files could tear; and (c) private storage has no index to benefit from
 * per-item paths. Clients merge concurrent writers per entry
 * (last-write-wins on the entry's millisecond timestamp) and write back the
 * resolved document, in which each listing key appears in `items` or
 * `tombstones` but never both.
 */
class PubkyMarketWatchlist {
    static __wrap(ptr) {
        const obj = Object.create(PubkyMarketWatchlist.prototype);
        obj.__wbg_ptr = ptr;
        PubkyMarketWatchlistFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketWatchlistFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketwatchlist_free(ptr, 0);
    }
    /**
     * Monotonically increasing document revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkymarketwatchlist_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkymarketwatchlist_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyMarketWatchlist}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkymarketwatchlist_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyMarketWatchlist.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkymarketwatchlist_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing document revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkymarketwatchlist_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkymarketwatchlist_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketWatchlist.prototype[Symbol.dispose] = PubkyMarketWatchlist.prototype.free;
exports.PubkyMarketWatchlist = PubkyMarketWatchlist;

/**
 * One actively watched listing.
 *
 * `watched_at_ms` is milliseconds since the UNIX epoch. Entry timestamps are
 * integers (not ISO-8601 strings like the document-level `createdAt` /
 * `updatedAt`) on purpose: they are last-write-wins merge keys that clients
 * compare numerically, and integer milliseconds cannot be skewed by
 * offset-formatting differences between writers.
 */
class PubkyMarketWatchlistItem {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketWatchlistItemFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketwatchlistitem_free(ptr, 0);
    }
    /**
     * Milliseconds since the UNIX epoch when the watch was (re)asserted.
     * @returns {bigint}
     */
    get watched_at_ms() {
        const ret = wasm.__wbg_get_pubkymarketwatchlistitem_watched_at_ms(this.__wbg_ptr);
        return ret;
    }
    /**
     * Milliseconds since the UNIX epoch when the watch was (re)asserted.
     * @param {bigint} arg0
     */
    set watched_at_ms(arg0) {
        wasm.__wbg_set_pubkymarketwatchlistitem_watched_at_ms(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketWatchlistItem.prototype[Symbol.dispose] = PubkyMarketWatchlistItem.prototype.free;
exports.PubkyMarketWatchlistItem = PubkyMarketWatchlistItem;

/**
 * A removed watch, retained so a delete wins over a stale re-add during merge.
 *
 * `removed_at_ms` is milliseconds since the UNIX epoch (see
 * [`PubkyMarketWatchlistItem`] for why entry timestamps are integers).
 */
class PubkyMarketWatchlistTombstone {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyMarketWatchlistTombstoneFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkymarketwatchlisttombstone_free(ptr, 0);
    }
    /**
     * Milliseconds since the UNIX epoch when the watch was removed.
     * @returns {bigint}
     */
    get removed_at_ms() {
        const ret = wasm.__wbg_get_pubkymarketwatchlisttombstone_removed_at_ms(this.__wbg_ptr);
        return ret;
    }
    /**
     * Milliseconds since the UNIX epoch when the watch was removed.
     * @param {bigint} arg0
     */
    set removed_at_ms(arg0) {
        wasm.__wbg_set_pubkymarketwatchlisttombstone_removed_at_ms(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyMarketWatchlistTombstone.prototype[Symbol.dispose] = PubkyMarketWatchlistTombstone.prototype.free;
exports.PubkyMarketWatchlistTombstone = PubkyMarketWatchlistTombstone;

class ReviewResponseResult {
    static __wrap(ptr) {
        const obj = Object.create(ReviewResponseResult.prototype);
        obj.__wbg_ptr = ptr;
        ReviewResponseResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ReviewResponseResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_reviewresponseresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.reviewresponseresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyMarketReviewResponse}
     */
    get review_response() {
        const ret = wasm.reviewresponseresult_review_response(this.__wbg_ptr);
        return PubkyMarketReviewResponse.__wrap(ret);
    }
}
if (Symbol.dispose) ReviewResponseResult.prototype[Symbol.dispose] = ReviewResponseResult.prototype.free;
exports.ReviewResponseResult = ReviewResponseResult;

class ReviewResult {
    static __wrap(ptr) {
        const obj = Object.create(ReviewResult.prototype);
        obj.__wbg_ptr = ptr;
        ReviewResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ReviewResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_reviewresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.reviewresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyMarketReview}
     */
    get review() {
        const ret = wasm.reviewresult_review(this.__wbg_ptr);
        return PubkyMarketReview.__wrap(ret);
    }
}
if (Symbol.dispose) ReviewResult.prototype[Symbol.dispose] = ReviewResult.prototype.free;
exports.ReviewResult = ReviewResult;

class ShippingProfileResult {
    static __wrap(ptr) {
        const obj = Object.create(ShippingProfileResult.prototype);
        obj.__wbg_ptr = ptr;
        ShippingProfileResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ShippingProfileResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_shippingprofileresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.shippingprofileresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyMarketShippingProfile}
     */
    get shipping_profile() {
        const ret = wasm.shippingprofileresult_shipping_profile(this.__wbg_ptr);
        return PubkyMarketShippingProfile.__wrap(ret);
    }
}
if (Symbol.dispose) ShippingProfileResult.prototype[Symbol.dispose] = ShippingProfileResult.prototype.free;
exports.ShippingProfileResult = ShippingProfileResult;

class ShopResult {
    static __wrap(ptr) {
        const obj = Object.create(ShopResult.prototype);
        obj.__wbg_ptr = ptr;
        ShopResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ShopResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_shopresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.shopresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyMarketShop}
     */
    get shop() {
        const ret = wasm.shopresult_shop(this.__wbg_ptr);
        return PubkyMarketShop.__wrap(ret);
    }
}
if (Symbol.dispose) ShopResult.prototype[Symbol.dispose] = ShopResult.prototype.free;
exports.ShopResult = ShopResult;

class WatchlistResult {
    static __wrap(ptr) {
        const obj = Object.create(WatchlistResult.prototype);
        obj.__wbg_ptr = ptr;
        WatchlistResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WatchlistResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_watchlistresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.watchlistresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyMarketWatchlist}
     */
    get watchlist() {
        const ret = wasm.watchlistresult_watchlist(this.__wbg_ptr);
        return PubkyMarketWatchlist.__wrap(ret);
    }
}
if (Symbol.dispose) WatchlistResult.prototype[Symbol.dispose] = WatchlistResult.prototype.free;
exports.WatchlistResult = WatchlistResult;

/**
 * Builds a drop record. The path ID equals the record's `dropId` (a
 * marketplace entity id chosen by the seller); the path is public so
 * indexers can read the drop.
 * @param {string} owner_pubky
 * @param {any} drop
 * @returns {DropResult}
 */
function buildDrop(owner_pubky, drop) {
    const ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildDrop(ptr0, len0, drop);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return DropResult.__wrap(ret[0]);
}
exports.buildDrop = buildDrop;

/**
 * Builds a listing record. A fresh timestamp ID is generated and written
 * into the record's `listingId`.
 * @param {string} owner_pubky
 * @param {any} listing
 * @returns {ListingResult}
 */
function buildListing(owner_pubky, listing) {
    const ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildListing(ptr0, len0, listing);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ListingResult.__wrap(ret[0]);
}
exports.buildListing = buildListing;

/**
 * Builds the `pubky://` URI of a Market record exactly as the per-kind
 * builders of `pubky-app-specs` do: the owner and id are concatenated
 * without validation, an empty id builds the collection path, and a missing
 * id is an error.
 *
 * `kind` is one of `shop`, `listing`, `drop`, `review`, `review_response`,
 * `watchlist`, `order_receipt`, `shipping_profile`, `attestor_profile`,
 * `attestor_annotation`.
 * Singletons (`shop`, `watchlist`, `attestor_profile`) ignore `id`; every
 * other kind takes the listing, drop, review, receipt or shipping profile id, or the
 * annotation's order reference.
 * @param {string} owner_pubky
 * @param {string} kind
 * @param {string | null} [id]
 * @returns {string}
 */
function buildMarketUri(owner_pubky, kind, id) {
    let deferred5_0;
    let deferred5_1;
    try {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = isLikeNone(id) ? 0 : passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.buildMarketUri(ptr0, len0, ptr1, len1, ptr2, len2);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}
exports.buildMarketUri = buildMarketUri;

/**
 * Builds a private order receipt. The path ID equals the record's
 * `receiptId` (the transaction service's receipt UUID); the path lives under
 * `/priv/pubky.app/`.
 * @param {string} owner_pubky
 * @param {any} receipt
 * @returns {OrderReceiptResult}
 */
function buildOrderReceipt(owner_pubky, receipt) {
    const ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildOrderReceipt(ptr0, len0, receipt);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return OrderReceiptResult.__wrap(ret[0]);
}
exports.buildOrderReceipt = buildOrderReceipt;

/**
 * Builds a review record. The hash ID is derived from the reviewed listing
 * URI, subject, role and (when present) `orderRef`, and written into the
 * record's `reviewId`.
 * @param {string} owner_pubky
 * @param {any} review
 * @returns {ReviewResult}
 */
function buildReview(owner_pubky, review) {
    const ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildReview(ptr0, len0, review);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ReviewResult.__wrap(ret[0]);
}
exports.buildReview = buildReview;

/**
 * Builds a review-response record. The path ID equals the subject review's
 * ID carried in the record's `reviewId`.
 * @param {string} owner_pubky
 * @param {any} response
 * @returns {ReviewResponseResult}
 */
function buildReviewResponse(owner_pubky, response) {
    const ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildReviewResponse(ptr0, len0, response);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ReviewResponseResult.__wrap(ret[0]);
}
exports.buildReviewResponse = buildReviewResponse;

/**
 * Builds a shipping profile record. The path ID equals the record's
 * `profileId` (a marketplace entity id chosen by the seller).
 * @param {string} owner_pubky
 * @param {any} shipping_profile
 * @returns {ShippingProfileResult}
 */
function buildShippingProfile(owner_pubky, shipping_profile) {
    const ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildShippingProfile(ptr0, len0, shipping_profile);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ShippingProfileResult.__wrap(ret[0]);
}
exports.buildShippingProfile = buildShippingProfile;

/**
 * Builds a shop record (singleton at `/pub/pubky.app/marketplace/v1/shop.json`).
 * @param {string} owner_pubky
 * @param {any} shop
 * @returns {ShopResult}
 */
function buildShop(owner_pubky, shop) {
    const ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildShop(ptr0, len0, shop);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ShopResult.__wrap(ret[0]);
}
exports.buildShop = buildShop;

/**
 * Builds the private watchlist document. Its path lives under
 * `/priv/pubky.app/`: only the owner's authenticated sessions can read or
 * write it.
 * @param {string} owner_pubky
 * @param {any} watchlist
 * @returns {WatchlistResult}
 */
function buildWatchlist(owner_pubky, watchlist) {
    const ptr0 = passStringToWasm0(owner_pubky, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildWatchlist(ptr0, len0, watchlist);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return WatchlistResult.__wrap(ret[0]);
}
exports.buildWatchlist = buildWatchlist;

/**
 * The item counting key of one review record, `iss:order_ref:role:listing_owner:listing_id`:
 * runs the full verification recipe (`verifyPurchaseAttestation`) on the
 * record (camelCase JSON) and keys it by its attested order and listing.
 * Whether `iss` is a trusted attestor remains the caller's policy decision.
 * @param {any} review
 * @returns {string}
 */
function itemCountKey(review) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.itemCountKey(review);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.itemCountKey = itemCountKey;

/**
 * The single `shippingOptions` entry written beside zones so readers that
 * predate them still parse the listing. `currency` and `exponent` are the
 * zones' asset.
 * @param {any} zones
 * @param {string} currency
 * @param {number} exponent
 * @param {string} option_id
 * @param {string} label
 * @returns {any}
 */
function legacyShippingOption(zones, currency, exponent, option_id, label) {
    const val4 = +exponent;
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passStringToWasm0(currency, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(option_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passStringToWasm0(label, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.legacyShippingOption(zones, ptr0, len0, val4, ptr1, len1, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.legacyShippingOption = legacyShippingOption;

/**
 * Parses and structurally validates a compact JWS drop edition
 * attestation, returning its claims as a plain JSON object. Does NOT
 * verify the signature — see `verifyDropEditionAttestation`.
 * @param {string} jws
 * @returns {any}
 */
function parseDropEditionAttestation(jws) {
    const ptr0 = passStringToWasm0(jws, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parseDropEditionAttestation(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.parseDropEditionAttestation = parseDropEditionAttestation;

/**
 * Parses a `pubky://<owner>/pub/pubky.app/...` URI. A Market record gives
 * the same result as `parse_uri` in `pubky-app-specs`; any other `pubky.app`
 * path gives the resource `unknown`.
 * @param {string} uri
 * @returns {ParsedUriResult}
 */
function parseMarketUri(uri) {
    const ptr0 = passStringToWasm0(uri, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parseMarketUri(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ParsedUriResult.__wrap(ret[0]);
}
exports.parseMarketUri = parseMarketUri;

/**
 * Parses and structurally validates a compact JWS order receipt
 * attestation, returning its v1 or v2 claims as a plain JSON object with
 * the attestation's wire-format snake_case keys (`total_minor` for v1;
 * `settlement_total` and `merchandise_total` for v2). Does NOT verify the
 * signature — see `verifyOrderReceiptAttestation`.
 * @param {string} jws
 * @returns {any}
 */
function parseOrderReceiptAttestation(jws) {
    const ptr0 = passStringToWasm0(jws, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parseOrderReceiptAttestation(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.parseOrderReceiptAttestation = parseOrderReceiptAttestation;

/**
 * Parses and structurally validates a compact JWS purchase attestation,
 * returning its claims as a plain JSON object. Does NOT verify the
 * signature — see `verifyPurchaseAttestation`.
 * @param {string} jws
 * @returns {any}
 */
function parsePurchaseAttestation(jws) {
    const ptr0 = passStringToWasm0(jws, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parsePurchaseAttestation(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.parsePurchaseAttestation = parsePurchaseAttestation;

/**
 * The `price_decade` claim value for a listing unit price: `currency`,
 * `exponent` and `unitPriceMinor` (a safe-integer number or a BigInt) as
 * the listing writes them, e.g. `priceDecade("BTC", 8, 25000)` ->
 * `"BTC:4"`. Table currencies are decaded in the table's minor unit
 * (satoshis for BTC). `undefined` when there is no decade to sign.
 * @param {string} currency
 * @param {number} exponent
 * @param {any} unit_price_minor
 * @returns {string | undefined}
 */
function priceDecade(currency, exponent, unit_price_minor) {
    const val2 = +exponent;
    const ptr0 = passStringToWasm0(currency, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.priceDecade(ptr0, len0, val2, unit_price_minor);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    let v3;
    if (ret[0] !== 0) {
        v3 = getStringFromWasm0(ret[0], ret[1]);
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    }
    return v3;
}
exports.priceDecade = priceDecade;

/**
 * The 1-5 price weight of a review from its attestation's `price_decade`
 * claim (`"{CURRENCY}:{k}"`); a missing claim (`undefined` or `null`) or an
 * unknown currency weighs 1, and a malformed value throws.
 * @param {string | null} [price_decade]
 * @returns {number}
 */
function priceWeight(price_decade) {
    var ptr0 = isLikeNone(price_decade) ? 0 : passStringToWasm0(price_decade, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len0 = WASM_VECTOR_LEN;
    const ret = wasm.priceWeight(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0];
}
exports.priceWeight = priceWeight;

/**
 * Quotes every rate of the zone that serves `destination`, in the zone's
 * order. Throws the same codes as `quoteShipping`.
 * @param {any} zones
 * @param {any} excluded_countries
 * @param {string} destination
 * @param {number} units
 * @returns {any}
 */
function quoteAllShippingRates(zones, excluded_countries, destination, units) {
    const val2 = +units;
    const ptr0 = passStringToWasm0(destination, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.quoteAllShippingRates(zones, excluded_countries, ptr0, len0, val2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.quoteAllShippingRates = quoteAllShippingRates;

/**
 * Quotes one shipping group of `units` units to `destination` (an uppercase
 * ISO 3166-1 alpha-2 code) under the rate `rateId` of the zone that serves
 * it. `zones` is a profile's or listing's zone array and `excludedCountries`
 * the profile's excluded countries (or undefined). Returns the quote
 * (`zoneId`, `rateId`, `label`, `amountMinor`, `estimatedMinDays`,
 * `estimatedMaxDays`) or throws the stable error code
 * (`SHIPPING_UNAVAILABLE_TO_COUNTRY`, `UNKNOWN_SHIPPING_RATE`,
 * `INVALID_DESTINATION`, `INVALID_QUANTITY`, `SHIPPING_OVERFLOW`).
 * @param {any} zones
 * @param {any} excluded_countries
 * @param {string} destination
 * @param {string} rate_id
 * @param {number} units
 * @returns {any}
 */
function quoteShipping(zones, excluded_countries, destination, rate_id, units) {
    const val3 = +units;
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passStringToWasm0(destination, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(rate_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.quoteShipping(zones, excluded_countries, ptr0, len0, ptr1, len1, val3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.quoteShipping = quoteShipping;

/**
 * The seller rating key of one review record, `iss:order_ref:role`, after
 * the same verification as `itemCountKey`. Every item review of one order
 * shares it, so `shipping` and `communication` count once per order.
 * @param {any} review
 * @returns {string}
 */
function sellerRatingKey(review) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.sellerRatingKey(review);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.sellerRatingKey = sellerRatingKey;

/**
 * Verifies an attestor annotation fetched from `uri` (its raw JSON text):
 * the URI must be an attestor annotation path, the `proof` must verify
 * against the URI's owner, and `orderRef` must equal the path ID. Returns
 * the record as a plain object.
 * @param {string} uri
 * @param {string} json
 * @returns {any}
 */
function verifyAttestorAnnotation(uri, json) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passStringToWasm0(uri, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.verifyAttestorAnnotation(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.verifyAttestorAnnotation = verifyAttestorAnnotation;

/**
 * Verifies an attestor profile fetched from `uri` (its raw JSON text):
 * the URI must be an attestor profile path and the `proof` must verify
 * against the URI's owner over the canonical body. Returns the record as a
 * plain object. Whether the attestor is trusted remains the caller's
 * policy decision; a profile may only narrow that trust.
 * @param {string} uri
 * @param {string} json
 * @returns {any}
 */
function verifyAttestorProfile(uri, json) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passStringToWasm0(uri, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.verifyAttestorProfile(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.verifyAttestorProfile = verifyAttestorProfile;

/**
 * The full local verification recipe for one drop-order receipt record:
 * parses the record (camelCase JSON) against the spec, requires both the
 * `editionAttestation` JWS and the `drop` display object to be present,
 * verifies the Ed25519 signature against the `iss` pubky, and checks the
 * claim bindings. Returns the verified claims. Whether `iss` is a
 * *trusted* attestor remains the caller's policy decision.
 * @param {any} receipt
 * @returns {any}
 */
function verifyDropEditionAttestation(receipt) {
    const ret = wasm.verifyDropEditionAttestation(receipt);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.verifyDropEditionAttestation = verifyDropEditionAttestation;

/**
 * The full local verification recipe for one order receipt record: parses
 * the record (camelCase JSON) against the spec, parses its embedded
 * attestation, verifies the Ed25519 signature against the `iss` pubky, and
 * checks the claim bindings. Returns the verified v1 or v2 claims with the
 * same snake_case keys. For v2, `settlement_total` is signed but is not bound
 * to a field in the receipt record. Whether `iss` is a trusted attestor
 * remains the caller's policy decision.
 * @param {any} receipt
 * @returns {any}
 */
function verifyOrderReceiptAttestation(receipt) {
    const ret = wasm.verifyOrderReceiptAttestation(receipt);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.verifyOrderReceiptAttestation = verifyOrderReceiptAttestation;

/**
 * The full local verification recipe for one review record: parses the
 * record (camelCase JSON) against the spec, parses its embedded
 * attestation, verifies the Ed25519 signature against the `iss` pubky, and
 * checks the claim bindings. Returns the verified claims with wire-format
 * snake_case keys. Whether `iss` is a *trusted* attestor remains the caller's policy decision.
 * @param {any} review
 * @returns {any}
 */
function verifyPurchaseAttestation(review) {
    const ret = wasm.verifyPurchaseAttestation(review);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.verifyPurchaseAttestation = verifyPurchaseAttestation;
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_208446807d0d1e30: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_Number_ff192a72a0dcdf6d: function(arg0) {
            const ret = Number(arg0);
            return ret;
        },
        __wbg_String_8564e559799eccda: function(arg0, arg1) {
            const ret = String(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 1, len1, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_bigint_get_as_i64_11da4b52cd0aedef: function(arg0, arg1) {
            const v = arg1;
            const ret = typeof(v) === 'bigint' ? v : undefined;
            getDataViewMemory0().setBigInt64((arg0 >>> 0) + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_boolean_get_4f1baf9a00be3c74: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_debug_string_f249a2a76caa9a55: function(arg0, arg1) {
            const ret = debugString(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 1, len1, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_in_3f58a9d3b3a7eed2: function(arg0, arg1) {
            const ret = arg0 in arg1;
            return ret;
        },
        __wbg___wbindgen_is_bigint_5fa10641e039d3ef: function(arg0) {
            const ret = typeof(arg0) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_function_741ff2bb612836f5: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_c22311b1cc228e3a: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_8b968c3ab8e96595: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_fc456fee5d3317de: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_be5b34249ff1fc15: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_38d7bfbe4cc84039: function(arg0, arg1) {
            const ret = arg0 === arg1;
            return ret;
        },
        __wbg___wbindgen_jsval_loose_eq_b2f214e2e4b30e36: function(arg0, arg1) {
            const ret = arg0 == arg1;
            return ret;
        },
        __wbg___wbindgen_number_get_934b640d0889af78: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64((arg0 >>> 0) + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_7ce8eee7fd327545: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 1, len1, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_4c88d8bf264fd984: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_call_40b008ba32f73991: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.call(arg1);
            return ret;
        }, arguments); },
        __wbg_done_57e08d0be6e30c02: function(arg0) {
            const ret = arg0.done;
            return ret;
        },
        __wbg_entries_7bb1459bd9b5c2b9: function(arg0) {
            const ret = Object.entries(arg0);
            return ret;
        },
        __wbg_get_635eea311fa1a291: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_d7176cfb76d71114: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_unchecked_e6325ad374eff861: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_with_ref_key_fc601247060b7204: function(arg0, arg1) {
            const ret = arg0[arg1];
            return ret;
        },
        __wbg_instanceof_ArrayBuffer_12cdaa4161423e6b: function(arg0) {
            let result;
            try {
                result = arg0 instanceof ArrayBuffer;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Map_0b4fc8b62e73f163: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Map;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_d7aeb0dcb3108fea: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_bcf1376d0d732d08: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_isSafeInteger_1a35ba4d31e71d38: function(arg0) {
            const ret = Number.isSafeInteger(arg0);
            return ret;
        },
        __wbg_iterator_e4c5e8f68ada7b58: function() {
            const ret = Symbol.iterator;
            return ret;
        },
        __wbg_length_186163212ffe79c3: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_b03a0fabb109b1e9: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_new_13de428334042d26: function(arg0) {
            const ret = new Uint8Array(arg0);
            return ret;
        },
        __wbg_new_37eb45aaf5eeb820: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_7075786089b89c5e: function() {
            const ret = new Map();
            return ret;
        },
        __wbg_new_cd4348290afae586: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_next_178c1651c11432b3: function(arg0) {
            const ret = arg0.next;
            return ret;
        },
        __wbg_next_af5ac6a08bb0a717: function() { return handleError(function (arg0) {
            const ret = arg0.next();
            return ret;
        }, arguments); },
        __wbg_now_463ac581d2fc7ea3: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_prototypesetcall_13162965d1fe7aa3: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_set_8282f7e0d2d01336: function(arg0, arg1, arg2) {
            const ret = arg0.set(arg1, arg2);
            return ret;
        },
        __wbg_set_d2d33b52458e984a: function(arg0, arg1, arg2) {
            arg0[arg1 >>> 0] = arg2;
        },
        __wbg_set_e4b9a833d288759a: function(arg0, arg1, arg2) {
            arg0[arg1] = arg2;
        },
        __wbg_value_e0f328965e184931: function(arg0) {
            const ret = arg0.value;
            return ret;
        },
        __wbindgen_generic_0000000000000001: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000002: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_generic_0000000000000004: function(arg0) {
            // Cast intrinsic for `U64 -> Externref`.
            const ret = BigInt.asUintN(64, arg0);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            table.set(0, undefined);
            table.set(1024, undefined);
            table.set(1025, null);
            table.set(1026, true);
            table.set(1027, false);
        },
    };
    return {
        __proto__: null,
        "./pubky_market_specs_bg.js": import0,
    };
}

const DropResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_dropresult_free(ptr, 1));
const ListingResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_listingresult_free(ptr, 1));
const MetaFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_meta_free(ptr, 1));
const OrderReceiptResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_orderreceiptresult_free(ptr, 1));
const ParsedUriResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_parseduriresult_free(ptr, 1));
const PubkyIdFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyid_free(ptr, 1));
const PubkyMarketDropFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketdrop_free(ptr, 1));
const PubkyMarketListingFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketlisting_free(ptr, 1));
const PubkyMarketLocationFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketlocation_free(ptr, 1));
const PubkyMarketMoneyFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketmoney_free(ptr, 1));
const PubkyMarketOrderReceiptFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketorderreceipt_free(ptr, 1));
const PubkyMarketReviewFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketreview_free(ptr, 1));
const PubkyMarketReviewRatingsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketreviewratings_free(ptr, 1));
const PubkyMarketReviewResponseFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketreviewresponse_free(ptr, 1));
const PubkyMarketShippingProfileFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketshippingprofile_free(ptr, 1));
const PubkyMarketShopFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketshop_free(ptr, 1));
const PubkyMarketWatchlistFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketwatchlist_free(ptr, 1));
const PubkyMarketWatchlistItemFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketwatchlistitem_free(ptr, 1));
const PubkyMarketWatchlistTombstoneFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkymarketwatchlisttombstone_free(ptr, 1));
const ReviewResponseResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_reviewresponseresult_free(ptr, 1));
const ReviewResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_reviewresult_free(ptr, 1));
const ShippingProfileResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_shippingprofileresult_free(ptr, 1));
const ShopResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_shopresult_free(ptr, 1));
const WatchlistResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_watchlistresult_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function debugString(val) {
    switch (typeof val) {
        // primitive types
        case 'number':
        case 'boolean':
        case 'undefined':
        return `${val}`;
        case 'string':
        return JSON.stringify(val);
        case 'bigint':
        return `${val}n`;
        case 'symbol':
        return val.description !== undefined
            ? `Symbol(${val.description})`
            : 'Symbol';
        case 'function':
        return typeof val.name === 'string' && val.name !== ''
            ? `Function(${val.name})`
            : 'Function';
        case 'object': {
            if (val === null) {
                return 'null';
            }
            // objects
            if (Array.isArray(val)) {
                return '[' + Array.from(val, debugString).join(', ') + ']';
            }
            // errors
            if (val instanceof Error) {
                return `${val.name}: ${val.message}\n${val.stack}`;
            }

            const toStringOutput = toString.call(val);
            // Test for built-in
            const className = /\[object ([^\]]+)\]/.exec(toStringOutput)?.[1];

            // Failed to match the standard '[object ClassName]'
            if (className === undefined) {
                return toStringOutput;
            }
            if (className === 'Object') {
                // we're a user defined class or Object
                // JSON.stringify avoids problems with cycles, and is generally much
                // easier than looping through ownProperties of `val`.
                try {
                    return 'Object(' + JSON.stringify(val) + ')';
                } catch (_) {
                    return 'Object';
                }
            }
            // TODO we could test for more things here, like `Set`s and `Map`s.
            return className;
        }
        // Per MDN: 'This list of values is exhaustive.'
        // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/typeof#description
    }
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true });
cachedTextDecoder.decode();
function decodeText(bytes) {
    return cachedTextDecoder.decode(bytes);
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

const wasmPath = `${__dirname}/pubky_market_specs_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
let wasmInstance = new WebAssembly.Instance(wasmModule, __wbg_get_imports());
let wasm = wasmInstance.exports;
wasm.__wbindgen_start();
