/* tslint:disable */
/* eslint-disable */

export class DropResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly drop: PubkyMarketDrop;
    readonly meta: Meta;
}

export class ListingResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly listing: PubkyMarketListing;
    readonly meta: Meta;
}

/**
 * Each `build*` function:
 * - Accepts the record as a plain camelCase JSON object and the owner's pubky.
 * - Sanitizes and validates the record.
 * - Derives the ID where the record has one.
 * - Returns the record with its `meta` (`id`, `path`, `url`), or a descriptive error.
 */
export class Meta {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly id: string;
    readonly path: string;
    readonly url: string;
}

export class OrderReceiptResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly order_receipt: PubkyMarketOrderReceipt;
}

/**
 * The result of parsing a Market URI: the owner, the resource name (the
 * `Display` form of [`Resource`], e.g. `marketplace/v1/listings`) and the
 * resource id when it has one.
 */
export class ParsedUriResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly resource: string;
    readonly resource_id: string | undefined;
    readonly user_id: string;
}

/**
 * A validated Pubky public key in its 52-character z-base-32 form.
 *
 * Native targets accept exactly the keys `pubky::PublicKey` accepts for a
 * 52-character input (the decoded 32 bytes must be a valid Ed25519 point)
 * and store the canonical re-encoding, as `pubky-app-specs` does. The wasm
 * target checks length and encoding only, also as `pubky-app-specs` does.
 */
export class PubkyId {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

/**
 * Represents a marketplace drop: a seller's scheduled, limited-quantity
 * release bundling one or more of their listings.
 *
 * URI: /pub/pubky.app/marketplace/v1/drops/:drop_id
 *
 * Where drop_id follows the marketplace entity-id convention and must match
 * the record's `dropId` field. Unlike the private order receipt, this is a
 * PUBLIC record wired into `PubkyMarketObject` and the URI parser so Nexus can
 * index it.
 *
 * `startsAt`/`endsAt` are the seller's declared schedule intent; the
 * marketplace transaction service enforces the real sale window and the
 * real stock counters. `listingIds` are the seller's OWN listings: the drop
 * record owner is the listing owner by definition (both live under the same
 * pubky's `/pub/pubky.app/marketplace/v1/` tree), so no cross-owner
 * reference form exists here.
 */
export class PubkyMarketDrop {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyMarketDrop;
    toJson(): any;
    /**
     * Per-buyer purchase cap, 1-100; never above `total_quantity`.
     */
    per_buyer_limit: bigint;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    /**
     * Total units across the drop, 1-1000000.
     */
    total_quantity: bigint;
    /**
     * Getter for `drop_id`.
     */
    readonly drop_id: string;
    /**
     * Getter for `owner_pubky`.
     */
    readonly owner_pubky: string;
    /**
     * Getter for `title`.
     */
    readonly title: string;
}

/**
 * How a drop sells. Closed-world: this version defines only `fcfs`
 * (first-come, first-served); any future format is a schema version bump,
 * so records carrying an unknown format are rejected rather than
 * misinterpreted.
 */
export enum PubkyMarketDropFormat {
    Fcfs = 0,
}

/**
 * How much remaining-stock detail the seller wants the public projection to
 * reveal while the drop runs. This is the seller's DECLARED policy —
 * ENFORCEMENT is server-side: the transaction service (which holds the real
 * counters) decides what each stock query answers, and the public record
 * merely tells clients which presentation the seller chose.
 */
export enum PubkyMarketDropStockDisplay {
    Exact = 0,
    Bands = 1,
    Hidden = 2,
}

/**
 * How the item can be delivered to the buyer.
 */
export enum PubkyMarketFulfillmentMethod {
    Physical = 0,
    Digital = 1,
    Pickup = 2,
    /**
     * Carrier delivery. Distinct from `physical`, which still requires package
     * facts and a shipping option. A listing may offer `shipping` alone.
     */
    Shipping = 3,
}

/**
 * Represents a marketplace listing published by a seller.
 *
 * URI: /pub/pubky.app/marketplace/v1/listings/:listing_id
 *
 * Where listing_id is Crockford-base32 encoding of a timestamp and must
 * match the record's `listingId` field.
 */
export class PubkyMarketListing {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyMarketListing;
    toJson(): any;
    adult_only: boolean;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    /**
     * Marketplace category taxonomy version, `1` or greater. The category
     * tree and the attribute expectations per category are versioned CLIENT
     * configuration keyed by this number — the record stays self-describing
     * without the spec churning per category.
     */
    taxonomy_version: bigint;
    /**
     * Getter for `description`.
     */
    readonly description: string;
    /**
     * Getter for `listing_id`.
     */
    readonly listing_id: string;
    /**
     * Getter for `owner_pubky`.
     */
    readonly owner_pubky: string;
    /**
     * Getter for `title`.
     */
    readonly title: string;
}

/**
 * Physical condition of the listed item.
 */
export enum PubkyMarketListingCondition {
    New = 0,
    LikeNew = 1,
    Excellent = 2,
    Good = 3,
    Fair = 4,
    ForParts = 5,
}

/**
 * Media attachment type.
 */
export enum PubkyMarketListingMediaKind {
    Image = 0,
    Video = 1,
}

/**
 * Lifecycle state of a marketplace listing.
 */
export enum PubkyMarketListingState {
    Active = 0,
    Paused = 1,
    Ended = 2,
    Removed = 3,
}

/**
 * Coarse public location attached to shops and listings.
 */
export class PubkyMarketLocation {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

/**
 * Integer money in minor units, e.g. cents or satoshis.
 *
 * `amount_minor` is always an integer amount of the smallest unit,
 * `currency` is an uppercase asset code and `exponent` the number of
 * decimal places between minor and major units.
 */
export class PubkyMarketMoney {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    amount_minor: bigint;
    exponent: bigint;
}

/**
 * A PRIVATE portable order receipt — the buyer's or seller's own durable
 * copy of a completed order, written to their OWN homeserver.
 *
 * URI: /priv/pubky.app/marketplace/v1/receipts/:receipt_id
 *
 * The marketplace transaction service holds the canonical order state, but
 * a service is an operator that can disappear. This record is the credible
 * exit for orders: each party keeps a signed, self-contained receipt (the
 * embedded `receiptAttestation` JWS is offline-verifiable — see
 * `order_receipt_attestation.rs`) on storage they control, so a purchase
 * history survives the operator.
 *
 * Like the watchlist, this is a `/priv/` record: an order history reveals
 * counterparties, amounts, and purchase timing, so it must never be
 * world-readable, directory-listable, or Nexus-indexable. It is therefore
 * deliberately NOT wired into `PubkyMarketObject` / the URI parser used by
 * watchers and indexers: nothing under `/priv/` is index-visible, and this
 * record only ever travels between the owner's own sessions.
 *
 * Unlike the watchlist singleton, receipts are one record per order under
 * `receipts/:receipt_id` (the service's receipt UUID): receipts are
 * immutable facts, not merge targets, and per-id paths let a client sync
 * incrementally instead of rewriting one growing document.
 */
export class PubkyMarketOrderReceipt {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyMarketOrderReceipt;
    toJson(): any;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    /**
     * Getter for `order_id`.
     */
    readonly order_id: string;
    /**
     * Getter for `owner_pubky`.
     */
    readonly owner_pubky: string;
    /**
     * Getter for `receipt_id`.
     */
    readonly receipt_id: string;
}

/**
 * The record owner's side of the order.
 */
export enum PubkyMarketOrderReceiptRole {
    Buyer = 0,
    Seller = 1,
}

/**
 * Represents a marketplace review of a trade counterparty.
 *
 * URI: /pub/pubky.app/marketplace/v1/reviews/:review_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/marketplace/v1/reviews/FPB0AM9S93Q3M1GFY1KV09GMQM`
 *
 * Where review_id is
 * Crockford-base32(Blake3("{reviewed_listing_uri}:{subject_pubky}:{role}:{order_ref}")[:half])
 * and must match the record's `reviewId` field. A record without `orderRef`
 * (written before per-order reviews) keeps the three-part
 * `"{reviewed_listing_uri}:{subject_pubky}:{role}"` input.
 */
export class PubkyMarketReview {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyMarketReview;
    toJson(): any;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    /**
     * Getter for `listing_id`.
     */
    readonly listing_id: string;
    /**
     * Getter for `subject_pubky`.
     */
    readonly subject_pubky: string;
    /**
     * Getter for `text`.
     */
    readonly text: string;
}

/**
 * Star ratings on a 1-5 integer scale. Only `overall` is required.
 */
export class PubkyMarketReviewRatings {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    get communication(): bigint | undefined;
    set communication(value: bigint | null | undefined);
    get item_accuracy(): bigint | undefined;
    set item_accuracy(value: bigint | null | undefined);
    overall: bigint;
    get shipping(): bigint | undefined;
    set shipping(value: bigint | null | undefined);
}

/**
 * Represents a response to a marketplace review, published by the review's
 * subject on their own homeserver.
 *
 * URI: /pub/pubky.app/marketplace/v1/review_responses/:review_id
 *
 * The path ID **equals the subject review's ID**, which gives O(1) lookup
 * in both directions and structurally caps responses at one per review
 * (revisable via `revision`).
 *
 * Authorization is structural, not cryptographic: an indexer accepts a
 * response only when the response record's `owner_pubky` equals the
 * subject review's `subjectPubky` (see [`Self::is_authorized_response_to`]).
 * An impostor's response fails that check without any signature machinery.
 */
export class PubkyMarketReviewResponse {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyMarketReviewResponse;
    toJson(): any;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    /**
     * Getter for `review_id`.
     */
    readonly review_id: string;
    /**
     * Getter for `review_uri`.
     */
    readonly review_uri: string;
    /**
     * Getter for `text`.
     */
    readonly text: string;
}

/**
 * Which side of the trade the review covers.
 */
export enum PubkyMarketReviewRole {
    BuyerReviewingSeller = 0,
    SellerReviewingBuyer = 1,
}

/**
 * A seller's reusable shipping rules: where they ship from, which countries
 * they ship to and what each zone charges. Listings reference a profile by
 * its id, or carry their own zones.
 *
 * URI: /pub/pubky.app/marketplace/v1/shipping_profiles/:profile_id
 *
 * Amounts are integer minor units of the profile's `currency` and
 * `exponent`; a listing can use the profile only in the same asset.
 */
export class PubkyMarketShippingProfile {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyMarketShippingProfile;
    toJson(): any;
    /**
     * Decimal places between the minor and major unit of `currency`.
     */
    exponent: bigint;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    /**
     * Getter for `owner_pubky`.
     */
    readonly owner_pubky: string;
    /**
     * Getter for `profile_id`.
     */
    readonly profile_id: string;
}

/**
 * Represents a seller's marketplace shop profile (singleton per user).
 *
 * URI: /pub/pubky.app/marketplace/v1/shop.json
 */
export class PubkyMarketShop {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyMarketShop;
    toJson(): any;
    /**
     * Monotonically increasing record revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
    vacation_mode: boolean;
    /**
     * Getter for `bio`.
     */
    readonly bio: string;
    /**
     * Getter for `name`.
     */
    readonly name: string;
    /**
     * Getter for `owner_pubky`.
     */
    readonly owner_pubky: string;
}

/**
 * Represents a user's PRIVATE marketplace watchlist.
 *
 * URI: /priv/pubky.app/marketplace/v1/watchlist.json
 *
 * This is the first record under `/priv/` — the homeserver's authenticated
 * private storage (reads, listings, and writes by anyone but the owner's
 * session are refused). A watchlist reveals purchase intent, so unlike every
 * `/pub/pubky.app/` record it must not be world-readable, directory-listable,
 * or Nexus-indexable. It is therefore deliberately NOT wired into
 * `PubkyMarketObject` / the URI parser used by watchers and indexers: nothing
 * under `/priv/` is index-visible, and this record only ever travels between
 * the owner's own sessions.
 *
 * It is a SINGLE revisioned document rather than one record per watched
 * listing because: (a) watch/unwatch toggles are high-churn and a single
 * document makes each sync one `PUT` instead of a create/delete stream;
 * (b) merge needs items and tombstones resolved together atomically — two
 * files could tear; and (c) private storage has no index to benefit from
 * per-item paths. Clients merge concurrent writers per entry
 * (last-write-wins on the entry's millisecond timestamp) and write back the
 * resolved document, in which each listing key appears in `items` or
 * `tombstones` but never both.
 */
export class PubkyMarketWatchlist {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static fromJson(js_value: any): PubkyMarketWatchlist;
    toJson(): any;
    /**
     * Monotonically increasing document revision, starting at 1.
     */
    revision: bigint;
    /**
     * Marketplace contract version, always `1`.
     */
    schema_version: bigint;
}

/**
 * One actively watched listing.
 *
 * `watched_at_ms` is milliseconds since the UNIX epoch. Entry timestamps are
 * integers (not ISO-8601 strings like the document-level `createdAt` /
 * `updatedAt`) on purpose: they are last-write-wins merge keys that clients
 * compare numerically, and integer milliseconds cannot be skewed by
 * offset-formatting differences between writers.
 */
export class PubkyMarketWatchlistItem {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Milliseconds since the UNIX epoch when the watch was (re)asserted.
     */
    watched_at_ms: bigint;
}

/**
 * A removed watch, retained so a delete wins over a stale re-add during merge.
 *
 * `removed_at_ms` is milliseconds since the UNIX epoch (see
 * [`PubkyMarketWatchlistItem`] for why entry timestamps are integers).
 */
export class PubkyMarketWatchlistTombstone {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Milliseconds since the UNIX epoch when the watch was removed.
     */
    removed_at_ms: bigint;
}

export class ReviewResponseResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly review_response: PubkyMarketReviewResponse;
}

export class ReviewResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly review: PubkyMarketReview;
}

export class ShippingProfileResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly shipping_profile: PubkyMarketShippingProfile;
}

export class ShopResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly shop: PubkyMarketShop;
}

export class WatchlistResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly meta: Meta;
    readonly watchlist: PubkyMarketWatchlist;
}

/**
 * Builds a drop record. The path ID equals the record's `dropId` (a
 * marketplace entity id chosen by the seller); the path is public so
 * indexers can read the drop.
 */
export function buildDrop(owner_pubky: string, drop: any): DropResult;

/**
 * Builds a listing record. A fresh timestamp ID is generated and written
 * into the record's `listingId`.
 */
export function buildListing(owner_pubky: string, listing: any): ListingResult;

/**
 * Builds the `pubky://` URI of a Market record exactly as the per-kind
 * builders of `pubky-app-specs` do: the owner and id are concatenated
 * without validation, an empty id builds the collection path, and a missing
 * id is an error.
 *
 * `kind` is one of `shop`, `listing`, `drop`, `review`, `review_response`,
 * `watchlist`, `order_receipt`, `shipping_profile`, `attestor_profile`,
 * `attestor_annotation`.
 * Singletons (`shop`, `watchlist`, `attestor_profile`) ignore `id`; every
 * other kind takes the listing, drop, review, receipt or shipping profile id, or the
 * annotation's order reference.
 */
export function buildMarketUri(owner_pubky: string, kind: string, id?: string | null): string;

/**
 * Builds a private order receipt. The path ID equals the record's
 * `receiptId` (the transaction service's receipt UUID); the path lives under
 * `/priv/pubky.app/`.
 */
export function buildOrderReceipt(owner_pubky: string, receipt: any): OrderReceiptResult;

/**
 * Builds a review record. The hash ID is derived from the reviewed listing
 * URI, subject, role and (when present) `orderRef`, and written into the
 * record's `reviewId`.
 */
export function buildReview(owner_pubky: string, review: any): ReviewResult;

/**
 * Builds a review-response record. The path ID equals the subject review's
 * ID carried in the record's `reviewId`.
 */
export function buildReviewResponse(owner_pubky: string, response: any): ReviewResponseResult;

/**
 * Builds a shipping profile record. The path ID equals the record's
 * `profileId` (a marketplace entity id chosen by the seller).
 */
export function buildShippingProfile(owner_pubky: string, shipping_profile: any): ShippingProfileResult;

/**
 * Builds a shop record (singleton at `/pub/pubky.app/marketplace/v1/shop.json`).
 */
export function buildShop(owner_pubky: string, shop: any): ShopResult;

/**
 * Builds the private watchlist document. Its path lives under
 * `/priv/pubky.app/`: only the owner's authenticated sessions can read or
 * write it.
 */
export function buildWatchlist(owner_pubky: string, watchlist: any): WatchlistResult;

/**
 * The item counting key of one review record, `iss:order_ref:role:listing_owner:listing_id`:
 * runs the full verification recipe (`verifyPurchaseAttestation`) on the
 * record (camelCase JSON) and keys it by its attested order and listing.
 * Whether `iss` is a trusted attestor remains the caller's policy decision.
 */
export function itemCountKey(review: any): string;

/**
 * The single `shippingOptions` entry written beside zones so readers that
 * predate them still parse the listing. `currency` and `exponent` are the
 * zones' asset.
 */
export function legacyShippingOption(zones: any, currency: string, exponent: number, option_id: string, label: string): any;

/**
 * Parses and structurally validates a compact JWS drop edition
 * attestation, returning its claims as a plain JSON object. Does NOT
 * verify the signature — see `verifyDropEditionAttestation`.
 */
export function parseDropEditionAttestation(jws: string): any;

/**
 * Parses a `pubky://<owner>/pub/pubky.app/...` URI. A Market record gives
 * the same result as `parse_uri` in `pubky-app-specs`; any other `pubky.app`
 * path gives the resource `unknown`.
 */
export function parseMarketUri(uri: string): ParsedUriResult;

/**
 * Parses and structurally validates a compact JWS order receipt
 * attestation, returning its v1 or v2 claims as a plain JSON object with
 * the attestation's wire-format snake_case keys (`total_minor` for v1;
 * `settlement_total` and `merchandise_total` for v2). Does NOT verify the
 * signature — see `verifyOrderReceiptAttestation`.
 */
export function parseOrderReceiptAttestation(jws: string): any;

/**
 * Parses and structurally validates a compact JWS purchase attestation,
 * returning its claims as a plain JSON object. Does NOT verify the
 * signature — see `verifyPurchaseAttestation`.
 */
export function parsePurchaseAttestation(jws: string): any;

/**
 * The `price_decade` claim value for a listing unit price: `currency`,
 * `exponent` and `unitPriceMinor` (a safe-integer number or a BigInt) as
 * the listing writes them, e.g. `priceDecade("BTC", 8, 25000)` ->
 * `"BTC:4"`. Table currencies are decaded in the table's minor unit
 * (satoshis for BTC). `undefined` when there is no decade to sign.
 */
export function priceDecade(currency: string, exponent: number, unit_price_minor: any): string | undefined;

/**
 * The 1-5 price weight of a review from its attestation's `price_decade`
 * claim (`"{CURRENCY}:{k}"`); a missing claim (`undefined` or `null`) or an
 * unknown currency weighs 1, and a malformed value throws.
 */
export function priceWeight(price_decade?: string | null): number;

/**
 * Quotes every rate of the zone that serves `destination`, in the zone's
 * order. Throws the same codes as `quoteShipping`.
 */
export function quoteAllShippingRates(zones: any, excluded_countries: any, destination: string, units: number): any;

/**
 * Quotes one shipping group of `units` units to `destination` (an uppercase
 * ISO 3166-1 alpha-2 code) under the rate `rateId` of the zone that serves
 * it. `zones` is a profile's or listing's zone array and `excludedCountries`
 * the profile's excluded countries (or undefined). Returns the quote
 * (`zoneId`, `rateId`, `label`, `amountMinor`, `estimatedMinDays`,
 * `estimatedMaxDays`) or throws the stable error code
 * (`SHIPPING_UNAVAILABLE_TO_COUNTRY`, `UNKNOWN_SHIPPING_RATE`,
 * `INVALID_DESTINATION`, `INVALID_QUANTITY`, `SHIPPING_OVERFLOW`).
 */
export function quoteShipping(zones: any, excluded_countries: any, destination: string, rate_id: string, units: number): any;

/**
 * The seller rating key of one review record, `iss:order_ref:role`, after
 * the same verification as `itemCountKey`. Every item review of one order
 * shares it, so `shipping` and `communication` count once per order.
 */
export function sellerRatingKey(review: any): string;

/**
 * Verifies an attestor annotation fetched from `uri` (its raw JSON text):
 * the URI must be an attestor annotation path, the `proof` must verify
 * against the URI's owner, and `orderRef` must equal the path ID. Returns
 * the record as a plain object.
 */
export function verifyAttestorAnnotation(uri: string, json: string): any;

/**
 * Verifies an attestor profile fetched from `uri` (its raw JSON text):
 * the URI must be an attestor profile path and the `proof` must verify
 * against the URI's owner over the canonical body. Returns the record as a
 * plain object. Whether the attestor is trusted remains the caller's
 * policy decision; a profile may only narrow that trust.
 */
export function verifyAttestorProfile(uri: string, json: string): any;

/**
 * The full local verification recipe for one drop-order receipt record:
 * parses the record (camelCase JSON) against the spec, requires both the
 * `editionAttestation` JWS and the `drop` display object to be present,
 * verifies the Ed25519 signature against the `iss` pubky, and checks the
 * claim bindings. Returns the verified claims. Whether `iss` is a
 * *trusted* attestor remains the caller's policy decision.
 */
export function verifyDropEditionAttestation(receipt: any): any;

/**
 * The full local verification recipe for one order receipt record: parses
 * the record (camelCase JSON) against the spec, parses its embedded
 * attestation, verifies the Ed25519 signature against the `iss` pubky, and
 * checks the claim bindings. Returns the verified v1 or v2 claims with the
 * same snake_case keys. For v2, `settlement_total` is signed but is not bound
 * to a field in the receipt record. Whether `iss` is a trusted attestor
 * remains the caller's policy decision.
 */
export function verifyOrderReceiptAttestation(receipt: any): any;

/**
 * The full local verification recipe for one review record: parses the
 * record (camelCase JSON) against the spec, parses its embedded
 * attestation, verifies the Ed25519 signature against the `iss` pubky, and
 * checks the claim bindings. Returns the verified claims with wire-format
 * snake_case keys. Whether `iss` is a *trusted* attestor remains the caller's policy decision.
 */
export function verifyPurchaseAttestation(review: any): any;
